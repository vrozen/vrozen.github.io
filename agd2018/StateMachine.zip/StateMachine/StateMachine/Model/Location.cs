/******************************************************************************
 * Copyright (c) 2018, Amsterdam University of Applied Sciences (HvA) and
 *                     Centrum Wiskunde & Informatica (CWI)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Contributors:
 *   * Riemer van Rozen - rozen@cwi.nl - HvA / CWI
 ******************************************************************************/
/*!
 * \namespace StateMachine.Model
 * \class     Location
 * \brief     Source locations define pieces of code inside a file.
 * \file      Location.cs
 * \author    Riemer van Rozen
 * \date      April 20th 2018
/******************************************************************************/
using System;

namespace StateMachine.Model
{
  public class Location
  {
    private readonly String path;

    private readonly Int32 offset;
    private readonly Int32 length;

    private readonly Int32 beginLine;
    private readonly Int32 endLine;

    private readonly Int32 beginColumn;
    private readonly Int32 endColumn;

    public Location()
    {
      this.path = null;
      this.offset = 0;
      this.length = 0;
      this.beginLine = 0;
      this.beginColumn = 0;
      this.endLine = 0;
      this.endColumn = 0;
    }

    public Location(String path, Int32 offset, Int32 length, Int32 beginLine, Int32 beginColumn, Int32 endLine, Int32 endColumn)
    {
      this.path = path;
      this.offset = offset;
      this.length = length;
      this.beginLine = beginLine;
      this.beginColumn = beginColumn;
      this.endLine = endLine;
      this.endColumn = endColumn;
    }

    public String getPath()
    {
      return path;
    }

    public Int32 getOffset()
    {
      return offset;
    }

    public Int32 getLength()
    {
      return length;
    }

    public Int32 getBeginLine()
    {
      return beginLine;
    }

    public Int32 getEndLine()
    {
      return endLine;
    }

    public Int32 getBeginColumn()
    {
      return beginColumn;
    }

    public Int32 getEndColumn()
    {
      return endColumn;
    }

    public bool Equals(Location other)
    {
      return this.offset == other.offset &&
             this.length == other.length &&
             this.beginLine == other.beginLine &&
             this.beginColumn == other.beginColumn &&
             this.endLine == other.endLine &&
             this.endColumn == other.endColumn &&
             this.path.Equals(other.path);
    }

    public override bool Equals(Object obj)
    {
      return (obj is Location) && Equals((Location)obj);
    }

    public override int GetHashCode()
    {
      return offset.GetHashCode() +
             length.GetHashCode() +
             beginLine.GetHashCode() +
             beginLine.GetHashCode() +
             endLine.GetHashCode() +
             endColumn.GetHashCode() +
             path.GetHashCode();
    }

    public override string ToString()
    {
      return "loc://" + path + "(" + offset + "," + length + "<" + beginLine + "," + beginColumn + ">,<" + endLine + "," + endColumn + ">)";
    }

  }
}