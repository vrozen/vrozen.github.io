﻿/******************************************************************************
 * Copyright (c) 2018, Amsterdam University of Applied Sciences (HvA) and
 *                     Centrum Wiskunde & Informatica (CWI)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Contributors:
 *   * Riemer van Rozen - rozen@cwi.nl - HvA / CWI
 ******************************************************************************/
/*!
 * \namespace StateMachine.Parser
 * \class     Builder
 * \brief     Visitor that builds state machine models.
 * \file      Builder.cs
 * \author    Riemer van Rozen
 * \date      April 20th 2018
/******************************************************************************/

using System;
using System.IO;
using Antlr4.Runtime;
using Antlr4.Runtime.Misc;
using Antlr4.Runtime.Tree;
using StateMachine.Model;

namespace StateMachine.Parser
{
  public class Builder : IStateMachineVisitor<Object>
  {
    private TextWriter output;
    private TextWriter errorOutput;
    private String path;
    private BuilderErrorListener listener;

    public class BuilderException : System.Exception
    {
      private readonly Location loc;

      public BuilderException(Location loc, String message) : base(message + " at " + loc.ToString())
      {
        this.loc = loc;
      }

      public Location getLocation()
      {
        return loc;
      }
    }

    private class BuilderErrorListener : BaseErrorListener
    {
      private Builder parser;

      public BuilderErrorListener(Builder parser)
      {
        this.parser = parser;
      }

      public override void SyntaxError(TextWriter output, IRecognizer recognizer, IToken offendingSymbol, int line, int charPositionInLine, string msg, RecognitionException e)
      {
        Location loc = new Location(parser.getPath(), offendingSymbol.StartIndex, offendingSymbol.StopIndex - offendingSymbol.StartIndex, offendingSymbol.Line, offendingSymbol.Column, offendingSymbol.Line, offendingSymbol.Column + offendingSymbol.Text.Length);
        throw new BuilderException(loc, msg);
      }
    }

    public Builder(TextWriter output, TextWriter errorOutput)
    {
      this.output = output;
      this.errorOutput = errorOutput;
      this.listener = new BuilderErrorListener(this);
    }

    private String getPath()
    {
      return path;
    }

    private Location getLocation(ParserRuleContext context)
    {
      int beginOffset = 0;
      int endOffset = 0;
      int beginLine = 0;
      int beginCol = 0;
      int endLine = 0;
      int endCol = 0;

      if (context.Start != null)
      {
        beginOffset = context.Start.StartIndex;
        beginLine = context.Start.Line;
        beginCol = context.Start.Column;
      }
      if (context.Stop != null)
      {
        endOffset = context.Stop.StopIndex;
        endLine = context.Stop.Line;
        endCol = context.Stop.Column;
      }
      int length = endOffset - beginOffset;

      return new Location(path, beginOffset, length, beginLine, beginCol, endLine, endCol);
    }

    private Location getLocation(IToken token)
    {
      return new Location(path, token.StartIndex, token.StopIndex - token.StartIndex, token.Line, token.Column, token.Line, token.Column + token.Text.Length);
    }


    //Note: not reentrant
    public Machine parse(String script)
    {
      AntlrInputStream input = new AntlrInputStream(script);
      StateMachineLexer lexer = new StateMachineLexer(input, output, errorOutput);
      CommonTokenStream stream = new CommonTokenStream(lexer);
      StateMachineParser parser = new StateMachineParser(stream, output, errorOutput);
      //parser.RemoveErrorListeners();
      //parser.AddErrorListener(listener);
      Machine machine = null;
      try
      {
        IParseTree tree = parser.machine();
        machine = (Machine)this.Visit(tree);
      }
      catch (BuilderException e)
      {
        Console.WriteLine(e.getLocation() + e.Message);
      }
      return machine;
    }

    public object VisitMachine([NotNull] StateMachineParser.MachineContext context)
    {
      String name = context.name.Text;
      Machine machine = new Machine(name);

      foreach (StateMachineParser.StateContext state in context.state())
      {
        machine.addState((State)Visit(state));
      }

      return machine;
    }

    public object VisitState([NotNull] StateMachineParser.StateContext context)
    {
      String name = context.name.Text;
      State state = new State(name);

      foreach (StateMachineParser.TransitionContext transition in context.transition())
      {
        state.addTransition((Transition)Visit(transition));
      }

      return state;
    }

    public object VisitTransition([NotNull] StateMachineParser.TransitionContext context)
    {
      String trigger = context.trigger.Text;
      String target = context.target.Text;
      Transition transition = new Transition(trigger, target);
      return transition;
    }

    public object Visit(IParseTree tree)
    {
      return tree.Accept(this);
    }

    public object VisitChildren(IRuleNode node)
    {
      return node.Accept(this);
    }

    public object VisitTerminal(ITerminalNode node)
    {
      return node.Accept(this);
    }

    public object VisitErrorNode(IErrorNode node)
    {
      return node.Accept(this);
    }
  }
}
